# Contributing

_earthaccess_ is community-owned and welcomes all forms of contributions from the public.

Please view
[our documentation's "contributing" page](https://earthaccess.readthedocs.io/en/latest/contributing)
to learn more!
