# Access

**Access** includes downloading files from a NASA DAAC or Earthdata Cloud to a local computer, a laptop, workstation or the storage space for a high-performace-computer (HPC); and also streaming data.

!!! note "This Page is a Work in Progress"

    We are reorganizing and updating the documentation, so not all pages are complete.  If you are looking for information about accessing data using earthaccess see the
    HOW-TO pages below.

    * [Quick start](../quick-start.md)
    * [How-to download data](../howto/onprem.md)

## Downloading data


## Streaming data
