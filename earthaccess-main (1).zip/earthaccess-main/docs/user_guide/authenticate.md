# Authentication

Introduces the `earthaccess.login` method for managing Earthdata Login and cloud credentials.

!!! note "This Page is a Work in Progress"

    We are reorganizing and updating the documentation, so not all pages are complete.  If you are looking for information about authenticating using earthaccess see the
    How-Tos and Tutorials in links below.

    * [Quick start](../quick-start.md)
    * [How-To Authenticate with earthaccess](../howto/authenticate.md)
