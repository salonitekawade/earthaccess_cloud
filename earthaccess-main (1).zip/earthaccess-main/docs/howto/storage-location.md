# Determine if a data set is on-prem or in the cloud

Coming soon
