# Documentation for `Granules`


### DataGranules is the class `earthaccess` uses to query CMR at the **granule** level.

::: earthaccess.search.DataGranules
    options:
      inherited_members: true
    show_root_heading: true
    show_source: false
