# Documentation for `Granule Results`

::: earthaccess.results.DataGranule
    options:
      inherited_members: true
    show_root_heading: true
    show_source: false
