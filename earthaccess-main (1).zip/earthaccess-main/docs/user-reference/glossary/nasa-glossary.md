# NASA EARTHDATA GLOSSARY

[GLOSSARY](https://earthdata.nasa.gov/learn/user-resources/glossary)
