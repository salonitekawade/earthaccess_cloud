# Documentation for `Collection Services`

::: earthaccess.DataServices
    options:
      inherited_members: true
    show_root_heading: true
    show_source: false
