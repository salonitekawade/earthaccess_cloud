# Documentation for `Collection Results`

::: earthaccess.results.DataCollection
    options:
      inherited_members: true
    show_root_heading: true
    show_source: false
