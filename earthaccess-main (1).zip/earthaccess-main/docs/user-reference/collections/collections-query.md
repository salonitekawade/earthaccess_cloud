# Documentation for `DataCollections`

### DataCollections is the class `earthaccess` uses to query CMR at the **dataset** level.

::: earthaccess.search.DataCollections
    options:
        show_source: false
        inherited_members: true
    show_source: false
