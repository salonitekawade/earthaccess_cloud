# Documentation for `Auth`

::: earthaccess.auth.Auth
    options:
      inherited_members: true
    show_root_heading: true
    show_source: false
