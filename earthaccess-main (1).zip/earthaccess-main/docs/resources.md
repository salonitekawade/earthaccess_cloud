# earthaccess presentations and external resources

* [earthaccess @ UCAR SEA Conference Slides ](https://docs.google.com/presentation/d/1g0LU01f_Y6S-ZHnXCzRNCyL0P2w7SQsvu65rw_6ZGaw/edit?usp=sharing)

* [earthaccess @ AGU poster](https://docs.google.com/presentation/d/1OOSZzbHv6Ck4lzOE01FQdI4kX0VCfcVBS4pWCc7dtBo/edit?usp=sharing)

* [NSIDC Cloud Data Access Guide](https://nsidc.org/data/user-resources/help-center/nasa-earthdata-cloud-data-access-guide)
